import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo';
  images: any[];
  constructor() {
    this.images = [
      { previewImageSource: 'https://images.unsplash.com/photo-1661956601030-fdfb9c7e9e2f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=442&q=80',
        alt: 'Image 1',
        title: 'Image 1',
        type: 'image',
        thumbnailImageSrc: 'https://images.unsplash.com/photo-1661956601030-fdfb9c7e9e2f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=442&q=80'
       },

       { previewImageSource: 'https://images.unsplash.com/photo-1661956600654-edac218fea67?ixlib=rb-4.0.3&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=436&q=80',
        alt: 'Image 1',
        title: 'Image 1',
        type: 'image',
        thumbnailImageSrc: 'https://images.unsplash.com/photo-1661956600654-edac218fea67?ixlib=rb-4.0.3&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=436&q=80'
       },

       { previewImageSource: 'https://images.pexels.com/photos/10396930/pexels-photo-10396930.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        alt: 'Image 1',
        title: 'Image 1',
        type: 'image',
        thumbnailImageSrc: 'https://images.pexels.com/photos/10396930/pexels-photo-10396930.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
       },

       { previewImageSource: 'https://images.pexels.com/photos/15115627/pexels-photo-15115627.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        alt: 'Image 1',
        title: 'Image 1',
        type: 'image',
        thumbnailImageSrc: 'https://images.pexels.com/photos/15115627/pexels-photo-15115627.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
       },

      
       {  type: 'video', 
          source: 'https://www.w3schools.com/html/mov_bbb.mp4',
          alt: 'Video 1', title: 'Video 1',
          thumbnailImageSrc: 'https://images.pexels.com/photos/15115627/pexels-photo-15115627.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', 
      }
      

      
    ];
  }

}
